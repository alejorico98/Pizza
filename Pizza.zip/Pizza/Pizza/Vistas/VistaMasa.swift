//
//  VistaMasa.swift
//  Pizza
//
//  Created by ALEJANDRO RICO ESPINOSA on 29/04/20.
//  Copyright © 2020 ALEJANDRO RICO ESPINOSA. All rights reserved.
//

import UIKit

class VistaMasa: UIViewController {
    
    //Variables
    var tamano:String=""
    var masa:String=""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func Delgada(_ sender: Any) {
        masa="Delgada"
    }
    @IBAction func Crujiente(_ sender: Any) {
        masa="Crujiente"
    }
    @IBAction func Gruesa(_ sender: Any) {
        masa="Gruesa"
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
           
           let sigVista = segue.destination as! VistaQueso
           sigVista.tamano=tamano
        sigVista.masa=masa
           
       }
    
    override func viewWillAppear(_ animated: Bool) {
        //muestraT.text=tamano
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
