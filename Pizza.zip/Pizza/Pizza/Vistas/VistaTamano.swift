//
//  VistaTamano.swift
//  Pizza
//
//  Created by ALEJANDRO RICO ESPINOSA on 29/04/20.
//  Copyright © 2020 ALEJANDRO RICO ESPINOSA. All rights reserved.
//

import UIKit

class VistaTamano: UIViewController {
    
    //Variables
    var tamano:String=""
    
    
    
    
    //Funciones
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func Chica(_ sender: Any) {
        tamano="Chica"
    }
    
    @IBAction func Mediana(_ sender: Any) {
        tamano="Mediana"
    }
    
    @IBAction func Grande(_ sender: Any) {
        tamano="Grande"
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let sigVista = segue.destination as! VistaMasa
        sigVista.tamano=tamano
        
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
