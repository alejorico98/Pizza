//
//  VistaIngredientes.swift
//  Pizza
//
//  Created by ALEJANDRO RICO ESPINOSA on 29/04/20.
//  Copyright © 2020 ALEJANDRO RICO ESPINOSA. All rights reserved.
//

import UIKit
import Foundation

class VistaIngredientes: UIViewController {
    
    //Variables
    var tamano:String=""
    var masa:String=""
    var queso:String=""
    var ingredientes=[String]()
    
    var jamo:Bool=false
    var pepp:Bool=false
    var salch:Bool=false
    var pav:Bool=false
    var ace:Bool=false
    var cebo:Bool=false
    var pimi:Bool=false
    var pin:Bool=false
    var anc:Bool=false
    
    @IBOutlet weak var BotJa: UIButton!
    @IBOutlet weak var BotPe: UIButton!
    @IBOutlet weak var BotSa: UIButton!
    @IBOutlet weak var BotPa: UIButton!
    @IBOutlet weak var BotAc: UIButton!
    @IBOutlet weak var BotCe: UIButton!
    @IBOutlet weak var BotPim: UIButton!
    @IBOutlet weak var BotPi: UIButton!
    @IBOutlet weak var BotAn: UIButton!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func Jamon(_ sender: Any) {
        if jamo==false{
            ingredientes.append("Jamon")
            jamo=true
            BotJa.backgroundColor=UIColor.blue
            
        }else{
            let indice=ingredientes.firstIndex(of: "Jamon")
                ingredientes.remove(at:(indice!))
            jamo=false
            BotJa.backgroundColor=UIColor.white
        }
        
    }
    
    @IBAction func Pepperoni(_ sender: Any) {
        if pepp==false{
            ingredientes.append("Pepperoni")
            pepp=true
            BotPe.backgroundColor=UIColor.blue
            
        }else{
            let indice=ingredientes.firstIndex(of: "Pepperoni")
                ingredientes.remove(at:(indice!))
            pepp=false
            BotPe.backgroundColor=UIColor.white
        }
    }
    
    @IBAction func Salchicha(_ sender: Any) {
        if salch==false{
            ingredientes.append("Salchicha")
            salch=true
            BotSa.backgroundColor=UIColor.blue
            
        }else{
            let indice=ingredientes.firstIndex(of: "Salchicha")
                ingredientes.remove(at:(indice!))
            salch=false
            BotSa.backgroundColor=UIColor.white
        }
    }
    
    @IBAction func Pavo(_ sender: Any) {
        if pav==false{
            ingredientes.append("Pavo")
            pav=true
            BotPa.backgroundColor=UIColor.blue
            
        }else{
            let indice=ingredientes.firstIndex(of: "Pavo")
                ingredientes.remove(at:(indice!))
            pav=false
            BotPa.backgroundColor=UIColor.white
        }
    }
    
    @IBAction func Aceituna(_ sender: Any) {
        if ace==false{
            ingredientes.append("Aceituna")
            ace=true
            BotAc.backgroundColor=UIColor.blue
            
        }else{
            let indice=ingredientes.firstIndex(of: "Aceituna")
                ingredientes.remove(at:(indice!))
            ace=false
            BotAc.backgroundColor=UIColor.white
        }
    }
    
    @IBAction func Cebolla(_ sender: Any) {
        if cebo==false{
            ingredientes.append("Cebolla")
            cebo=true
            BotCe.backgroundColor=UIColor.blue
            
        }else{
            let indice=ingredientes.firstIndex(of: "Cebolla")
                ingredientes.remove(at:(indice!))
            cebo=false
            BotCe.backgroundColor=UIColor.white
        }
    }
    
    @IBAction func Pimiento(_ sender: Any) {
        if pimi==false{
            ingredientes.append("Pimiento")
            pimi=true
            BotPim.backgroundColor=UIColor.blue
            
        }else{
            let indice=ingredientes.firstIndex(of: "Pimiento")
                ingredientes.remove(at:(indice!))
            pimi=false
            BotPim.backgroundColor=UIColor.white
        }
    }
    
    @IBAction func Pina(_ sender: Any) {
        if pin==false{
            ingredientes.append("Piña")
            pin=true
            BotPi.backgroundColor=UIColor.blue
            
        }else{
            let indice=ingredientes.firstIndex(of: "Piña")
                ingredientes.remove(at:(indice!))
            pin=false
            BotPi.backgroundColor=UIColor.white
        }
    }
    
    @IBAction func Anchova(_ sender: Any) {
        if anc==false{
            ingredientes.append("Anchova")
            anc=true
            BotAn.backgroundColor=UIColor.blue
            
        }else{
            let indice=ingredientes.firstIndex(of: "Anchova")
                ingredientes.remove(at:(indice!))
            anc=false
            BotAn.backgroundColor=UIColor.white
        }
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
          
          let sigVista = segue.destination as! VistaConfirmacion
          sigVista.tamano=tamano
       sigVista.masa=masa
    sigVista.queso=queso
        sigVista.ingredientes=ingredientes
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
