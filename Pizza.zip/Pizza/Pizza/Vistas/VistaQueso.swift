//
//  VistaQueso.swift
//  Pizza
//
//  Created by ALEJANDRO RICO ESPINOSA on 29/04/20.
//  Copyright © 2020 ALEJANDRO RICO ESPINOSA. All rights reserved.
//

import UIKit

class VistaQueso: UIViewController {
    
    //Variables
    var tamano:String=""
    var masa:String=""
    var queso:String=""
       

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func Mozarela(_ sender: Any) {
        queso="Mozarela"
    }
    
    @IBAction func Cheddar(_ sender: Any) {
        queso="Cheddar"
    }
    
    @IBAction func Parmesano(_ sender: Any) {
        queso="Parmesano"
    }
    
    @IBAction func SinQ(_ sender: Any) {
        queso="Sin Queso"
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
              
              let sigVista = segue.destination as! VistaIngredientes
              sigVista.tamano=tamano
           sigVista.masa=masa
        sigVista.queso=queso
              
          }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
