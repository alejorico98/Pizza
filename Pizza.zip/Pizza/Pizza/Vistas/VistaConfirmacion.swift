//
//  VistaConfirmacion.swift
//  Pizza
//
//  Created by ALEJANDRO RICO ESPINOSA on 29/04/20.
//  Copyright © 2020 ALEJANDRO RICO ESPINOSA. All rights reserved.
//

import UIKit

class VistaConfirmacion: UIViewController {
    
    //Variables
    var tamano:String=""
    var masa:String=""
    var queso:String=""
    var ingredientes=[String]()
    
    @IBOutlet weak var TamVisual: UILabel!
    @IBOutlet weak var MasaVisual: UILabel!
    @IBOutlet weak var QuesoVisual: UILabel!
    @IBOutlet weak var IngredienteVisual: UILabel!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
           TamVisual.text=tamano
        MasaVisual.text=masa
        QuesoVisual.text=queso
        IngredienteVisual.text="\(ingredientes)"
       }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
